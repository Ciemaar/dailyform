from warnings import warn

class FalseStr(str):
  def nonzero(self):
    return False

class FalseList(list):
  def nonzero(self):
    return False
    
class FalseDict(dict):
  def nonzero(self):
    return False
    
def falsify(obj):
  if isinstance(obj,str):
    return FalseStr(obj)
  elif isinstance(obj,list):
    return FalseList(obj)
  elif isinstance(obj,dict):
    return FalseDict(obj)
  else:
    warn("unable to create a proper false object")
    return False